## Application coverage

| Scope | Lines | Statements | Functions | Branches |
| --- | ---: | ---: | ---: | ---: |
| Total | 89.64% | 88.39% | 87.33% | 87.76% |
| backend | 89.02% | 89.02% | 91.26% | 91.5% |
| frontend | 90.6% | 87.51% | 86.4% | 85.62% |

All 78 application JS/JSX files are included, including untested files.
Required line coverage: 60% overall and independently for frontend/backend.
